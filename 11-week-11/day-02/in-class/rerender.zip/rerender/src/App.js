import logo from './logo.svg';
import './App.css';
import Counter from './components/Counter'
import UsersList from './components/UsersList'
import UsersListC from './components/UsersListC'

function App() {
  return (
    <div className="tc">

        <UsersListC />

    </div>
  );
}

export default App;
