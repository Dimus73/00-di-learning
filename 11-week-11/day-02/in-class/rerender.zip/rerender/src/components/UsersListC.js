import React from 'react'
import User from './User';
import Searchbox from './Searchbox'

class UsersListC extends React.Component {
  constructor(){
    super();
    this.state = {
      arr: [],
      search:''
    }
  }

   handleClick = () => {
     fetch('https://jsonplaceholder.typicode.com/users')
     .then(res => res.json())
     .then(data => {
       console.log(data);
       this.setState({arr:data})
     })
     .catch(err => {
       console.log(err);
     })
   }

   componentDidMount = () => {
     this.handleClick()
   }

   handleChange = (e) => {
     console.log(e.target.value);
     this.setState({search:e.target.value})
   }

   exampleMethod = (data) => {
     console.log(data);
   }

  render(){
    const {search} = this.state;

    const filteredArr = this.state.arr.filter(item=>{
      return item.name.toLowerCase().includes(search.toLowerCase())
    })

    return(
      <div>
      <Searchbox change={this.handleChange} title="My Search"/>
      {
        filteredArr.map(item => {
          return <User userinfo={item} key={item.id}/>
        })
      }
      </div>
    )
  }
}
export default UsersListC


// let state = {
//   search:''
// }
//
// const {search} = state
