const Searchbox = ({change, title}) => {
  // console.log(props);
  // const {change, title} = props

  return (
    <div>
    <h1>{title}</h1>
      <input type="text" placeholder="Filter..." onChange={(e)=>change(e)}/>
    </div>
  )
}
export default Searchbox
