import React from 'react';
import Counter from './components/Counter'
class ErrorBoundary extends React.Component {
  constructor() {
    super();
    this.state = {
      hasError: false,
      // error: null,
      // errorInfo: null,
    }
  }

  componentDidCatch(error,errorInfo) {
    console.log('error=>',error);
    console.log('errorInfo=>', errorInfo);
    this.setState({hasError:true})
    // write them to a log fil, send a messege to support teeam
  }

  render(){
    if(this.state.hasError){
      return (

       <Counter />

      )
    }
    return this.props.children
  }
}
export default ErrorBoundary
