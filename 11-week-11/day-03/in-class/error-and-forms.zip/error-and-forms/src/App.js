// import Parent from './components/Parent';
// import Child from './components/Child'
// import Counter from './components/Counter'
// import ErrorBoundary from './ErrorBoundary'
import { useState} from 'react'
import './App.css';

const App = () => {
  const [name, setName] = useState('John')

  const handleSubmit = (e) => {
    e.preventDefault();
  }
  //   const form = e.target;
  //   const formData = new FormData(form);
  //
  //   // console.log('formData=>',formData);
  //   // you can pass formData
  //   // fetch('/some-api',{mathod:form.method, body:formData})
  //
  //   // Or with plain Object
  //
  //   const formJson = Object.fromEntries(formData.entries())
  //   console.log(formJson);
  //
  //   fetch('/some-api',
  //   {method:form.method,
  //     body:{
  //       name:e.target.name.value,
  //       username:e.target.username.value
  //     })
  //
  // }
  return (
    <div className="App">
      <header className="App-header">
        <form onSubmit={handleSubmit} method='POST'>
        <label>
          Name: <input type="text" name="name" value={name}
          onChange={(e)=>setName(e.target.value)}
          />
        </label>
        <label>
          Username: <input type="text" name="username" />
        </label>
          <input type="submit" value="Send" />
        </form>
      </header>
    </div>
  );
}

export default App;


// <ErrorBoundary>
//   <Counter />
// </ErrorBoundary>
//
// <ErrorBoundary>
//   <Counter />
// </ErrorBoundary>
