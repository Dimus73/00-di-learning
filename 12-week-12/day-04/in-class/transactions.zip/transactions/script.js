// localStorage.setItem('car','mycar');

localStorage.clear();

// console.log(car);
