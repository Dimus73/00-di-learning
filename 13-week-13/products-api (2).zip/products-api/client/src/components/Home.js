import { useState, useEffect, useContext } from "react";
import { AppContext } from "../App";
import jwt_decode from "jwt-decode";
const Home = (props) => {
  const { accessToken } = useContext(AppContext);

  useEffect(() => {
    // if (accessToken) {
    //   console.log(accessToken);
    //   const decode = jwt_decode(accessToken.token);
    //   console.log(decode);
    // }

    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  const showButton = () => {
    return <button>small button</button>;
  };
  return (
    <div>
      <h1>Home</h1>
      {showButton()}
    </div>
  );
};
export default Home;
