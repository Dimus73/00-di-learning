import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Nav from "./components/Nav";
import LoginRegister from "./components/LoginRegister";
import { useState, createContext } from "react";
import "./App.css";
import { Auth } from "./auth/Auth";

export const AppContext = createContext(null);

function App() {
  const [accessToken, setAccessToken] = useState(null);
  return (
    <AppContext.Provider value={{ accessToken, setAccessToken }}>
      <div className="App">
        <Nav />
        <Routes>
          <Route
            path="/"
            element={
              <Auth>
                <Home />
              </Auth>
            }
          />
          <Route path="/login" element={<LoginRegister title="Login" />} />
          <Route
            path="/register"
            element={<LoginRegister title="Register" />}
          />
        </Routes>
      </div>
    </AppContext.Provider>
  );
}

export default App;
